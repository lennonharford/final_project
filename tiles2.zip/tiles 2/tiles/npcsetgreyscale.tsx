<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="npcsetgreyscale" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="8" columns="4">
 <image source="npcsetgreyscale.png" width="69" height="35"/>
</tileset>
